
var baseurl = 'http://localhost:3000'
function create() {
    // -------------------------------------
    //  YOUR CODE
    //  Create user account on server
    // -------------------------------------    
    console.log('Begin Create user account on server')
    console.log('End Create user account on server')   
    
    //frontend attributes 
    var name = document.getElementById('name_account').value
    var email = document.getElementById('email_account').value
    var password = document.getElementById('pwd_account').value
    console.log("Name, email , password:")
    console.log(name.trim(" ").length, email.trim(" ").length, password.trim(" ").length)

    if (name.trim(" ").length === 0) {
        swal("Error!", "Name can't be empty", "error");
        return;
    }
    else if (email.trim(" ").length === 0) {
        swal("Error!", "Email can't be empty", "error");
        return;
    }
    else if (password.trim(" ").length === 0) {
        swal("Error!", "Password can't be empty", "error");
        return;
    } 


    //backend url
    const url = baseurl + "/account/create/"+name+"/"+email+"/"+password 
    //make a call to the backend
    superagent
    .get(url)
    .end(function(err,res){
        if(err){ swal("Error in connecting to the backend!", "Message: "+err.message , "error"); return;    }
        else {
             resp = JSON.parse(JSON.parse(res.text))
             console.log("resp: ",resp)
             status = resp.status
             message = resp.message
             if (status==0) {
                swal("Error creating account!", message, "error"); 
                return;
            }
             if (status==1) {
                swal("Account created successfully!", message, "success"); 
                return;
            }
        }
    })
}

function login() {
    // -------------------------------------
    //  YOUR CODE
    //  Confirm credentials on server
    // -------------------------------------
    console.log('Begin login account on server')
    console.log('End login account on server')   
    
    //frontend attributes 
    var email = document.getElementById('email_login').value
    var password = document.getElementById('pwd_login').value
    console.log(email.trim(" ").length, password.trim(" ").length)
    
    if (email.trim(" ").length === 0) {
        swal("Error!", "Email can't be empty", "error");
        return;
    }
    else if (password.trim(" ").length === 0) {
        swal("Error!", "Password can't be empty", "error");
        return;
    } 

    //backend url
    const url = baseurl + "/account/login/"+email+"/"+password 
    
    //make a call to the backend
    superagent
    .get(url)
    .end(function(err,res){
        if(err){ swal("Error in connecting to the backend!", "Message: "+err.message , "error"); return;    }
        else {
                console.log("res: ",res)
                resp = res.body
                
                if (resp==null) {
                    swal("Error Logging in!", "Please check your credentials or contact help@mit.edu", "error"); 
                    return;
                }
                if (resp!=null) {
                    swal(`Hello ${resp.name}! `, "You've successfully logged in!" , "success"); 
                    return;
                }
        }
    })
    
}

function deposit() {
    // -------------------------------------
    //  YOUR CODE
    //  Deposit funds user funds on server
    // -------------------------------------
    console.log('Begin deposit funds on server')
    console.log('End deposit funds on server')   
    
    //frontend attributes 
    var email = document.getElementById('email_deposit').value
    var amount = document.getElementById('amount_deposit').value
    console.log("email , amount:")
    console.log(email.trim(" ").length, amount.trim(" ").length)

    if (email.trim(" ").length === 0) {
        swal("Error!", "Email can't be empty", "error");
        return;
    }
    else if (amount.trim(" ").length === 0) {
        swal("Error!", "Amount can't be empty", "error");
        return;
    } 


    //backend url
    const url = baseurl + "/account/deposit/"+email+"/"+amount 
    //make a call to the backend
    superagent
    .get(url)
    .end(function(err,res){
        if(err){ swal("Error in connecting to the backend!", "Message: "+err.message , "error"); return;    }
        else {
            console.log(res)
             resp = JSON.parse(res.body)

             console.log("resp: ",resp)
             status = resp.status
             message = resp.message
             if (status==0) {
                swal("Error depositing amount to account!", message, "error"); 
                return;
            }
             if (status==1) {
                swal("Amount deposited successfully!", message, "success"); 
                return;
            }
        }
    })
}

function withdraw() {
    // -------------------------------------
    //  YOUR CODE
    //  Withdraw funds user funds on server
    // -------------------------------------
    console.log('Begin withdraw funds on server')
    console.log('End withdraw funds on server')   
    
    //frontend attributes 
    var email = document.getElementById('email_withdraw').value
    var amount = document.getElementById('amount_withdraw').value
    console.log("email , amount:")
    console.log(email.trim(" ").length, amount.trim(" ").length)

    if (email.trim(" ").length === 0) {
        swal("Error!", "Email can't be empty", "error");
        return;
    }
    else if (amount.trim(" ").length === 0) {
        swal("Error!", "Amount can't be empty", "error");
        return;
    } 


    //backend url
    const url = baseurl + "/account/withdraw/"+email+"/"+amount 
    //make a call to the backend
    superagent
    .get(url)
    .end(function(err,res){
        if(err){ swal("Error in connecting to the backend!", "Message: "+err.message , "error"); return;    }
        else {
            console.log(res)
             resp = JSON.parse(res.body)

             console.log("resp: ",resp)
             status = resp.status
             message = resp.message
             if (status==0) {
                swal("Error withdrawing amount from account!", message, "error"); 
                return;
            }
             if (status==1) {
                swal("Amount withdrawn successfully!", message, "success"); 
                return;
            }
        }
    })
}

function transactions() {
    // -------------------------------------
    //  YOUR CODE
    //  Get all user transactions
    // -------------------------------------

    console.log('Begin show user transactions on server')
    console.log('End show user transactions funds on server')   
    
    //frontend attributes 
    var email = document.getElementById('email_transactions').value
    console.log("email")
    console.log(email.trim(" ").length)

    if (email.trim(" ").length === 0) {
        swal("Error!", "Email can't be empty", "error");
        return;
    }

    //table data
    user_transactions = document.getElementById('table_transactions')
                
    user_transactions.innerHTML = 
    "<thead><tr><th>Id</th><th>Transaction details</th></tr></thead>"

    //backend url
    const url = baseurl + "/account/transactions/"+email 
    //make a call to the backend
    superagent
    .get(url)
    .end(function(err,res){
        if(err){ swal("Error in connecting to the backend!", "Message: "+err.message , "error"); return;    }
        else {
             console.log("res: ",res)
             resp = JSON.parse(res.body)
             console.log("resp: ",resp)
             status = resp.status
             let transactions = resp.transactions
             if (status==0) {
                swal("Error fetching account!", "Account doesn't exist. Please contact help@mit.edu for more details.", "error"); 
                return;
            }
             if (status==1) {

                for (let i = 0; i < transactions.length; i++) {
                    console.log("id: ",i)
                    console.log("transaction: ",transactions[i])
                    user_transactions.innerHTML += '<tr><td>'+(i+1).toString()+'</td>' + '<td>'+transactions[i]+'</td></tr>'
                }
                 

                
                return;
            }
        }
    })
}

function balance() {
    // -------------------------------------
    //  YOUR CODE
    //  Get user balance
    // -------------------------------------
    console.log('Begin show balance funds on server')
    console.log('End show balance funds on server')   
    
    //frontend attributes 
    var email = document.getElementById('email_balance').value
    console.log("email")
    console.log(email.trim(" ").length)

    if (email.trim(" ").length === 0) {
        swal("Error!", "Email can't be empty", "error");
        return;
    }


    //backend url
    const url = baseurl + "/account/get/"+email 
    //make a call to the backend
    superagent
    .get(url)
    .end(function(err,res){
        if(err){ swal("Error in connecting to the backend!", "Message: "+err.message , "error"); return;    }
        else {
            console.log(res)
             resp = res.body

             if (resp==null) {
                swal("Error!", "The email is invalid. Please contact help@mit.edu for further details.", "error"); 
                return;
            }
            swal("Success fetching the balance!", resp.balance.toString()+"$");
        }
    })
}

function allData() {
    // -------------------------------------
    //  YOUR CODE
    //  Get all data
    // -------------------------------------
    console.log('Begin show all data on server')
    console.log('End show all data funds on server')   
    

    //backend url
    const url = baseurl + "/account/all/"

    //table element
    user_alldata = document.getElementById('table_alldata')
            
    user_alldata.innerHTML = 
    `
    <thead>
        <tr>
            <th>Name</th>
            <th>Balance</th>
            <th>Email</th>
            <th>Password</th>
            <th>Transaction details</th>
        </tr>
    </thead>
    `

    //make a call to the backend
    superagent
    .get(url)
    .end(function(err,res){
        if(err){ swal("Error in connecting to the backend!", "Message: "+err.message , "error"); return;    }
        else {
            console.log("res: ",res)
            resp = JSON.parse(res.body)
            alldata = resp
            console.log("alldata: ",alldata)

            for (let i = 0; i < alldata.length; i++) {
                user_alldata.innerHTML += '<tr>'+'<td>'+alldata[i].name+'</td>'+'<td>'+alldata[i].balance+'</td>' + '<td>'+alldata[i].email+'</td>' + '<td>'+alldata[i].password+'</td>' + '<td>'+alldata[i].transaction+'</td></tr>'
            }
            
            return;
        }
        
    })   
}

