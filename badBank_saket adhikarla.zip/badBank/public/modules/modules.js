var ui = {};

ui.navigation = `
    <!-- ------------- YOUR CODE: Navigation UI ------------- --> 
    <!-- Nav tabs -->
    <nav class="navbar navbar-default navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="nav navbar-nav mr-auto">
            <li>
                <a class="nav-link active navbar-brand" onclick="default()" href="#badbank">BadBank</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="loadCreateAccount()" href="#account" >Create Account </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="loadLogin()" href="#login" >Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onclick="loadDeposit()" href="#deposit">Deposit</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onclick="loadWithdraw()" href="#withdraw">Withdraw</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onclick="loadTransactions()" href="#transactions">Transactions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onclick="loadBalance()" href="#balance">Balance</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onclick="loadAllData()" href="#alldata">AllData</a>
            </li>
          </ul>
          
        </div>
      </nav>
`;

ui.createAccount = `
    <!-- ------------- YOUR CODE: Create Account UI ------------- --> 
    <!-- Account pane -->
    <div id = "account"> 
        <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
            <div class="card-header">Create Account</div>
            <div class="card-body">
                <p class="card-text">
                    <form>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" placeholder="Enter name" id="name_account">
                          </div>
                        <div class="form-group">
                          <label for="email">Email Address</label>
                          <input type="email" class="form-control" placeholder="Enter email" id="email_account">
                        </div>
                        <div class="form-group">
                          <label for="pwd">Password</label>
                          <input type="password" class="form-control" placeholder="Enter password" id="pwd_account">
                        </div>
                        <button type="button" class="btn" onclick="create()">Create Account</button>
                    </form>
                </p>
            </div>
          </div>
    </div>

`;

ui.login = `
    <!-- ------------- YOUR CODE: Login UI ------------- --> 
    <!-- Login pane -->
    <div id = "login" class="card text-white bg-secondary mb-3" style="max-width: 18rem;">  
        <div class="card-header">
            Login
        </div>
        <div class="card-body">
            <p class="card-text">
                <form>
                    <div class="form-group">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" placeholder="Enter email" id="email_login">
                    </div>
                    <div class="form-group">
                      <label for="pwd">Password</label>
                      <input type="password" class="form-control" placeholder="Enter password" id="pwd_login">
                    </div>
                    <button type="button" class="btn" onclick="login()">Login</button>
                </form>
            </p>
        </div>
    </div>

`;

ui.deposit = `
    <!-- ------------- YOUR CODE: Deposit UI ------------- --> 
    <!-- Deposit pane -->
    <div id = "deposit" class="card text-white bg-warning mb-3" style="max-width: 18rem;"> 
    <div class="card-header">
        Deposit
    </div>
    <div class="card-body">
        <p class="card-text">
            <form>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" placeholder="Enter email" id="email_deposit">
                </div>
                <div class="form-group">
                  <label for="pwd">Amount</label>
                  <input type="text" class="form-control" placeholder="Enter amount" id="amount_deposit">
                </div>
                <button type="button" class="btn" onclick="deposit()">Deposit</button>
            </form>
        </p>
    </div>
</div>
`;

ui.withdraw = `
    <!-- ------------- YOUR CODE: Withdraw UI ------------- --> 
    <!-- Withdraw pane -->
    <div id = "withdraw" class="card text-white bg-success mb-3" style="max-width: 18rem;"> 
        <div class="card-header">
            Withdraw
        </div>
        <div class="card-body">
            <p class="card-text">
                <form>
                    <div class="form-group">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" placeholder="Enter email" id="email_withdraw">
                    </div>
                    <div class="form-group">
                      <label for="pwd">Amount</label>
                      <input type="text" class="form-control" placeholder="Enter amount" id="amount_withdraw">
                    </div>
                    <button type="button" class="btn" onclick="withdraw()">Withdraw</button>
                </form>
            </p>
        </div>
    </div>
`;

ui.transactions = `
    <!-- ------------- YOUR CODE: Transactions UI ------------- --> 
    <!-- Transactions pane -->
    <div id = "transactions" class="card text-white bg-danger mb-3" style="max-width: 18rem;"> 
        <div class="card-header">
            Transactions
        </div>
        <div class="card-body">
            <p class="card-text">
                <form>
                    <div class="form-group">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" placeholder="Enter email" id="email_transactions">
                    </div>
                    <button type="button" class="btn" onclick="transactions()">Show Transactions</button>
                </form>
            </p>
        </div>
    </div> 
    <div id="table_transactions_wrapper" style="margin-top:8px;">
        <table id="table_transactions" class="table table-striped table-bordered" style="width:100%"></table>
    </div> 
`;

ui.balance = `
    <!-- ------------- YOUR CODE: Balance UI ------------- --> 
    <!-- Balance pane -->
    <div id = "balance" class="card text-white bg-info mb-3" style="max-width: 18rem;"> 
        <div class="card-header">
            Balance
        </div>
        <div class="card-body">
            <p class="card-text">
                <form>
                    <div class="form-group">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" placeholder="Enter email" id="email_balance">
                    </div>
                    <button type="button" class="btn" onclick="balance()">Show Balance</button>
                </form>
            </p>
        </div>
    </div>
`;

ui.default = `
    <!-- ------------- YOUR CODE: Default UI ------------- --> 
    <!-- Bank Pane -->
    <div id = "badbank" class="card bg-light mb-3" style="max-width: 18rem;">
        <div class="col-1"></div>
        <div class="card-header">BadBank landing module</div>
        <div class="card-body">
            <h5 class="card-title">Welcome to the Bank</h5>
            <p class="card-text">You can move around using the navigation bar.</p>
            <i class="fa fa-bank" style="font-size:206px"></i>
        </div>
    </div>
`;

ui.allData = `
    <!-- ------------- YOUR CODE: All Data UI ------------- --> 
    <!-- Alldata pane -->
    <div id = "alldata"> 
        <h3> All data in Store</h3>
        <button type="button" class= "btn btn-secondary" style="background-color: #6c757d" onclick="allData()">Show All Data</button>
    </div>
    <div id="table_alldata_wrapper" style="margin-top:8px;">
        <table id="table_alldata" class="table table-striped table-bordered"></table>
    </div> 

`;

var target     = document.getElementById('target');
var navigation = document.getElementById('navigation');
navigation.innerHTML += ui.navigation;

var loadCreateAccount = function(){
    target.innerHTML = ui.createAccount;
};

var loadLogin = function(){
    target.innerHTML = ui.login;
};

var loadDeposit = function(){
    target.innerHTML = ui.deposit;
};

var loadWithdraw = function(){
    target.innerHTML = ui.withdraw;
};

var loadTransactions = function(){
    target.innerHTML = ui.transactions;
};

var loadBalance = function(){
    target.innerHTML = ui.balance;
};

var defaultModule = function(){
    target.innerHTML = ui.default;
};

var loadAllData = function(){
    target.innerHTML = ui.allData;
};



defaultModule();
